# This file needs to be hosted.
# In the casino script config you can set the URL.